     High-res objects for Terra Nova
-----------------------------------------
By Gigaquad - http://terranova.110mb.com/


This program scales object textures (buildings, vehicles and explosions) to the highest resolution (256*256) the engine allows. The vegetation (trees, rocks) is left to original size since Terra Nova runs out of memory when hundreds of trees have large textures. Ground textures are not updated.

The scaling is done using the Scale2x algorithm: http://scale2x.sourceforge.net/
Images are not just enlarged, the best pixel colour is always chosen to give smoother lines and round corners.


Usage:
Place the program in the folder RESTNOBJ.RES is in and start the program. Making a backup first is advised.