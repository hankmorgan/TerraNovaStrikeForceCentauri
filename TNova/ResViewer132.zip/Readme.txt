====================================
ResViewer v1.32 for Flight Unlimited
====================================

Documentation is located in Readme.html
Double-Click on Readme.html or open it in your web browser.
